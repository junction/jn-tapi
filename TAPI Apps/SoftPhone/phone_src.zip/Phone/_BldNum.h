// Project: R:\Atapi\SAMPLE\Phone\Phone.dsp.  DO NOT MODIFY THIS FILE BY HAND.
//
#define BUILDNUM_ENABLED (0)
#define MODIFY_VERSIONINFO (0)
#define FILE_VERSION0 (1)
#define FILE_VERSION1 (0)
#define FILE_VERSION2 (0)
#define BUILD_NUMBER (0)
